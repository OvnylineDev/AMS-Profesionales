<?php
    /*
     * SOURCE: MS SQL
     */
    define('MSSQL_HOST','192.168.1'); /*Enlace*/
    define('MSSQL_USER','mssql_user'); /*Usuario*/
    define('MSSQL_PASSWORD','mssql_password');
    define('MSSQL_DATABASE','mssql_database');
    define('MSSQL_TABLES', array(   'TbUsuarios',
                                    'TbTiposFichero',
                                    'TbOperarios',
                                    'TbExpedientes',
                                    'TbExpedientesEstados',
                                    'TbExpedientesSeguimiento',
                                    'TbExpedientesFicheros',
                                    'TbIncidenciasFestivos',
                                    'TbIncidenciasFestivos_Ficheros'));

    // Connect MS SQL
    $mssql_connect = mssql_connect(MSSQL_HOST, MSSQL_USER, MSSQL_PASSWORD) or die("Couldn't connect to SQL Server on '".MSSQL_HOST."'' user '".MSSQL_USER."'\n");
        echo "=> Connected to Source MS SQL Server on '".MSSQL_HOST."'\n";

    // Select MS SQL Database
    $mssql_db = mssql_select_db(MSSQL_DATABASE, $mssql_connect) or die("Couldn't open database '".MSSQL_DATABASE."'\n"); 
        echo "=> Found database '".MSSQL_DATABASE."'\n";
    
?>